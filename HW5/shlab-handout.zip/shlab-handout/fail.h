
void fail(const char *s, ...);
