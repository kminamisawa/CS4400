void random_chaos(void);
void seed_chaos(int v);
